<?php $currentPage=basename($_SERVER['PHP_SELF']); $currentModule=$_GET['module']??''; ?>
<?php $serviceRoutes=['students'=>'students.php','lms'=>'lms.php','library'=>'library.php','security'=>'security.php','aid'=>'aid.php','dining'=>'dining.php']; $serviceNames=['students'=>'Student Information','lms'=>'Learning Management','library'=>'Library Management','security'=>'Campus Security','aid'=>'Financial Aid','dining'=>'Dining Services']; ?>
<aside class="sidebar">
	<div class="side-label">WORKSPACE</div>
	<a class="side-link <?=$currentPage==='dashboard.php'?'active':''?>" href="dashboard.php" <?=$currentPage==='dashboard.php'?'aria-current="page"':''?>>⌂ <span>Dashboard</span></a>
	<div class="side-label">CAMPUS SERVICES</div>
	<?php foreach (accessible_systems() as $system): $active=$currentPage===$serviceRoutes[$system] || ($currentPage==='module.php' && $currentModule===$system); ?>
	<a class="side-link <?=$active?'active':''?>" href="<?=$serviceRoutes[$system]?>" <?=$active?'aria-current="page"':''?>><span><?=$serviceNames[$system]?></span></a>
	<?php endforeach; ?>
</aside>