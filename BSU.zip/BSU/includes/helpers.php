<?php
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header("Location: {$url}"); exit; }
function require_login(): void { if (empty($_SESSION['user'])) redirect('login.php'); }
function current_user(): array { return $_SESSION['user'] ?? []; }
function flash(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function accessible_systems(): array {
    $role = current_user()['role'] ?? '';
    return match ($role) {
        'admin' => ['students', 'lms', 'library', 'security', 'aid', 'dining'],
        'student', 'instructor' => ['lms'],
        'staff', 'employee' => ['library', 'security', 'aid', 'dining'],
        default => [],
    };
}
function can_access_system(string $system): bool { return in_array($system, accessible_systems(), true); }
function require_system_access(string $system): void {
    if (!can_access_system($system)) {
        http_response_code(403);
        exit('You do not have permission to access this system.');
    }
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('Invalid form token. Please go back and try again.');
    }
}
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }
function count_rows(PDO $pdo, string $table): int {
    $allowed=['students','courses','books','library_loans','security_logs','aid_applications','dining_transactions','lms_items'];
    if (!in_array($table,$allowed,true)) return 0;
    return (int)$pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
}
