<?php
require_once __DIR__.'/config/bootstrap.php';
require_login();
require_system_access('lms');
verify_csrf();

$user=current_user();
$userId=(int)$user['id'];
$canTeach=in_array($user['role']??'', ['admin','instructor'], true);
$isStudent=($user['role']??'')==='student';
$isAdmin=($user['role']??'')==='admin';

$pdo->exec("CREATE TABLE IF NOT EXISTS lms_enrollments (
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, course_id INT NOT NULL,
 enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_lms_enrollment (user_id, course_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(course_id) REFERENCES courses(id) ON DELETE CASCADE
)");
$pdo->exec("CREATE TABLE IF NOT EXISTS lms_submissions (
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, lms_item_id INT NOT NULL,
 attempt_number INT NOT NULL, submission_text LONGTEXT NOT NULL, submission_url VARCHAR(1000) NULL,
 status ENUM('Submitted','Late','Graded') NOT NULL DEFAULT 'Submitted',
 score DECIMAL(7,2) NULL, feedback TEXT NULL, submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 graded_at DATETIME NULL, INDEX idx_lms_submission_item_user (lms_item_id, user_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(lms_item_id) REFERENCES lms_items(id) ON DELETE CASCADE
)");

$message='';
$selectedCourse=(int)($_GET['course']??$_POST['course_id']??0);
$redirectTo='lms.php'.($selectedCourse>0?'?course='.$selectedCourse:'');

if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    try{
        if($action==='create_course' && $canTeach){
            $code=strtoupper(trim($_POST['course_code']??''));
            $name=trim($_POST['course_name']??'');
            $instructor=$canTeach?trim($_POST['instructor']??''):'';
            $schedule=trim($_POST['schedule']??'');
            if($code===''||$name==='') throw new RuntimeException('Course code and course name are required.');
            if(($user['role']??'')==='instructor') $instructor=$user['full_name'];
            $stmt=$pdo->prepare('INSERT INTO courses (course_code,course_name,instructor,schedule) VALUES (?,?,?,?)');
            $stmt->execute([$code,$name,$instructor?:null,$schedule?:null]);
            flash('Course created.');
            redirect('lms.php?course='.(int)$pdo->lastInsertId());
        }

        if($action==='enroll' && $isStudent){
            $courseId=(int)($_POST['course_id']??0);
            $stmt=$pdo->prepare('INSERT IGNORE INTO lms_enrollments (user_id,course_id) SELECT ?,id FROM courses WHERE id=?');
            $stmt->execute([$userId,$courseId]);
            if($stmt->rowCount()) flash('You are enrolled in the course.');
            else flash('You are already enrolled or the course is unavailable.','error');
            redirect('lms.php?course='.$courseId);
        }

        if($action==='create_activity' && $canTeach){
            $courseId=(int)($_POST['course_id']??0);
            $type=$_POST['item_type']??'';
            $title=trim($_POST['title']??'');
            $description=trim($_POST['description']??'');
            $dueDate=trim($_POST['due_date']??'');
            if($courseId<1||$title===''||!in_array($type,['Material','Assignment','Quiz'],true)) throw new RuntimeException('Choose a course and activity type, and enter a title.');
            $courseCheck=$pdo->prepare('SELECT id FROM courses WHERE id=?');
            $courseCheck->execute([$courseId]);
            if(!$courseCheck->fetch()) throw new RuntimeException('The selected course does not exist.');
            if(!$isAdmin){
                $ownerCheck=$pdo->prepare('SELECT instructor FROM courses WHERE id=?');
                $ownerCheck->execute([$courseId]);
                if(strcasecmp(trim((string)$ownerCheck->fetchColumn()),trim((string)$user['full_name']))!==0) throw new RuntimeException('You can only publish activities in courses assigned to you.');
            }
            if($dueDate!=='' && !DateTime::createFromFormat('Y-m-d',$dueDate)) throw new RuntimeException('Enter a valid due date.');
            $stmt=$pdo->prepare('INSERT INTO lms_items (course_id,item_type,title,description,due_date) VALUES (?,?,?,?,?)');
            $stmt->execute([$courseId,$type,$title,$description?:null,$dueDate?:null]);
            flash('Learning activity published.');
            redirect('lms.php?course='.$courseId);
        }

        if($action==='submit_assignment' && $isStudent){
            $itemId=(int)($_POST['item_id']??0);
            $submissionText=trim($_POST['submission_text']??'');
            $submissionUrl=trim($_POST['submission_url']??'');
            $stmt=$pdo->prepare("SELECT i.id,i.due_date FROM lms_items i JOIN lms_enrollments e ON e.course_id=i.course_id AND e.user_id=? WHERE i.id=? AND i.item_type='Assignment'");
            $stmt->execute([$userId,$itemId]);
            $assignment=$stmt->fetch();
            if(!$assignment) throw new RuntimeException('Assignment not found or you are not enrolled in its course.');
            if($submissionText==='' && $submissionUrl==='') throw new RuntimeException('Enter your work or provide a submission link.');
            if($submissionUrl!=='' && (!filter_var($submissionUrl,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($submissionUrl,PHP_URL_SCHEME)),['http','https'],true))) throw new RuntimeException('Use a valid http or https submission link.');
            $attemptStmt=$pdo->prepare('SELECT COALESCE(MAX(attempt_number),0)+1 FROM lms_submissions WHERE user_id=? AND lms_item_id=?');
            $attemptStmt->execute([$userId,$itemId]);
            $attempt=(int)$attemptStmt->fetchColumn();
            $isLate=$assignment['due_date']!==null && $assignment['due_date']<date('Y-m-d');
            $stmt=$pdo->prepare('INSERT INTO lms_submissions (user_id,lms_item_id,attempt_number,submission_text,submission_url,status) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$userId,$itemId,$attempt,$submissionText,$submissionUrl?:null,$isLate?'Late':'Submitted']);
            flash('Submission attempt '.$attempt.' recorded.'.($isLate?' It was marked late.':''));
            redirect('lms.php?course='.(int)($_POST['course_id']??0));
        }

        if($action==='grade_submission' && $canTeach){
            $submissionId=(int)($_POST['submission_id']??0);
            $score=trim($_POST['score']??'');
            $feedback=trim($_POST['feedback']??'');
            if($score===''||!is_numeric($score)||(float)$score<0||(float)$score>100) throw new RuntimeException('Enter a score from 0 to 100.');
            $ownerClause=$isAdmin?'':' AND LOWER(TRIM(c.instructor))=LOWER(TRIM(?))';
            $stmt=$pdo->prepare("UPDATE lms_submissions s JOIN lms_items i ON i.id=s.lms_item_id JOIN courses c ON c.id=i.course_id SET s.score=?,s.feedback=?,s.status='Graded',s.graded_at=NOW() WHERE s.id=? AND i.item_type='Assignment'".$ownerClause);
            $params=[(float)$score,$feedback?:null,$submissionId];
            if(!$isAdmin) $params[]=$user['full_name'];
            $stmt->execute($params);
            if(!$stmt->rowCount()){
                $check=$pdo->prepare("SELECT id FROM lms_submissions WHERE id=? AND status='Graded'");
                $check->execute([$submissionId]);
                if(!$check->fetch()) throw new RuntimeException('Submission not found.');
            }
            flash('Submission grade saved.');
            redirect($redirectTo);
        }
        throw new RuntimeException('That action is not available for your account.');
    }catch(PDOException $exception){
        $message=$exception->getCode()==='23000'?'That course code is already in use.':'The request could not be saved. Please check the entered details.';
    }catch(RuntimeException $exception){
        $message=$exception->getMessage();
    }
}

$coursesStmt=$pdo->prepare("SELECT c.id,c.course_code,c.course_name,c.instructor,c.schedule,
 (SELECT COUNT(*) FROM lms_items i WHERE i.course_id=c.id) AS activity_count,
 (SELECT COUNT(*) FROM lms_enrollments e WHERE e.course_id=c.id) AS enrollment_count,
 EXISTS(SELECT 1 FROM lms_enrollments mine WHERE mine.course_id=c.id AND mine.user_id=?) AS is_enrolled
 FROM courses c ORDER BY c.course_code");
$coursesStmt->execute([$userId]);
$courses=$coursesStmt->fetchAll();

if($selectedCourse===0 && $courses){
    foreach($courses as $course){
        $isAssignedInstructor=$canTeach&&($isAdmin||strcasecmp(trim((string)$course['instructor']),trim((string)$user['full_name']))===0);
        if($isAssignedInstructor||($isStudent&&$course['is_enrolled'])){$selectedCourse=(int)$course['id'];break;}
    }
}
$activeCourse=null;
foreach($courses as $course){if((int)$course['id']===$selectedCourse){$activeCourse=$course;break;}}
$canManageSelectedCourse=$activeCourse&&$canTeach&&($isAdmin||strcasecmp(trim((string)$activeCourse['instructor']),trim((string)$user['full_name']))===0);
$canViewCourse=$activeCourse&&($canManageSelectedCourse||($isStudent&&$activeCourse['is_enrolled']));

$activities=[];
$submissions=[];
if($canViewCourse){
    $stmt=$pdo->prepare('SELECT * FROM lms_items WHERE course_id=? ORDER BY CASE item_type WHEN \'Assignment\' THEN 0 WHEN \'Quiz\' THEN 1 ELSE 2 END,due_date IS NULL,due_date,id DESC');
    $stmt->execute([$selectedCourse]);
    $activities=$stmt->fetchAll();
    if($canManageSelectedCourse){
        $stmt=$pdo->prepare("SELECT s.*,u.full_name,i.title AS assignment_title FROM lms_submissions s JOIN users u ON u.id=s.user_id JOIN lms_items i ON i.id=s.lms_item_id WHERE i.course_id=? AND i.item_type='Assignment' ORDER BY s.submitted_at DESC,s.attempt_number DESC");
        $stmt->execute([$selectedCourse]);
    }elseif($isStudent){
        $stmt=$pdo->prepare("SELECT s.*,u.full_name,i.title AS assignment_title FROM lms_submissions s JOIN users u ON u.id=s.user_id JOIN lms_items i ON i.id=s.lms_item_id WHERE i.course_id=? AND i.item_type='Assignment' AND s.user_id=? ORDER BY s.submitted_at DESC,s.attempt_number DESC");
        $stmt->execute([$selectedCourse,$userId]);
    }
    if($canTeach||$isStudent) $submissions=$stmt->fetchAll();
}

$flash=$_SESSION['flash']??null;
unset($_SESSION['flash']);
?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Learning Management System | BSU Connect</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="lms-page">
<?php include __DIR__.'/includes/header.php'; ?>
<div class="app-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><main class="main-content">
    <header class="lms-heading"><div><p class="eyebrow red">LEARNING MANAGEMENT</p><h1>Courses and coursework</h1><p class="muted">Course materials, assignments, and submission records in one place.</p></div>
    <?php if($canTeach): ?><a class="lms-primary-link" href="#create-course">Create course <span aria-hidden="true">+</span></a><?php endif; ?></header>
    <?php if($flash): ?><div class="alert <?=e($flash['type'])?>" role="status"><?=e($flash['message'])?></div><?php endif; ?>
    <?php if($message): ?><div class="alert error" role="alert"><?=e($message)?></div><?php endif; ?>

    <?php if($canTeach): ?>
    <section class="lms-create-course" id="create-course"><div><p class="eyebrow red">COURSE SETUP</p><h2>Create a course</h2></div><form method="post" class="lms-inline-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="create_course"><label><span>Course code</span><input name="course_code" maxlength="30" placeholder="IT403" required></label><label class="lms-course-name"><span>Course name</span><input name="course_name" maxlength="150" required></label><?php if(($user['role']??'')==='admin'): ?><label><span>Instructor</span><input name="instructor" maxlength="120"></label><?php endif; ?><label><span>Schedule</span><input name="schedule" maxlength="120" placeholder="Mon/Wed 10:00 AM"></label><button class="lms-button" type="submit">Create course</button></form></section>
    <?php endif; ?>

    <section class="lms-course-section"><div class="lms-section-title"><div><p class="eyebrow red">COURSE CATALOG</p><h2><?= $isStudent?'Available courses':'Your learning space' ?></h2></div><span class="lms-count"><?=count($courses)?> courses</span></div>
        <?php if(!$courses): ?><p class="lms-empty">No courses have been created yet.</p><?php else: ?>
        <div class="lms-course-list">
            <?php foreach($courses as $course): ?><article class="lms-course-row <?=((int)$course['id']===$selectedCourse?'is-active':'')?>"><a class="lms-course-main" href="lms.php?course=<?=(int)$course['id']?>"><span class="lms-course-code"><?=e($course['course_code'])?></span><span class="lms-course-info"><strong><?=e($course['course_name'])?></strong><small><?=e($course['instructor']?:'Instructor not assigned')?><?= $course['schedule']?' · '.e($course['schedule']):'' ?></small></span><span class="lms-course-meta"><?= (int)$course['activity_count'] ?> activities <span aria-hidden="true">&#8594;</span></span></a>
            <?php if($isStudent&&!$course['is_enrolled']): ?><form method="post" class="lms-enroll-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="enroll"><input type="hidden" name="course_id" value="<?=(int)$course['id']?>"><button class="lms-button secondary" type="submit">Enroll</button></form><?php elseif($isStudent): ?><span class="lms-enrolled">Enrolled</span><?php endif; ?></article><?php endforeach; ?>
        </div><?php endif; ?>
    </section>

    <?php if($canViewCourse): ?>
    <section class="lms-course-work"><div class="lms-section-title"><div><p class="eyebrow red"><?=e($activeCourse['course_code'])?></p><h2><?=e($activeCourse['course_name'])?></h2><p class="muted"><?=e($activeCourse['instructor']?:'Instructor not assigned')?><?= $activeCourse['schedule']?' · '.e($activeCourse['schedule']):'' ?></p></div><span class="lms-count"><?=count($activities)?> activities</span></div>
        <?php if($canManageSelectedCourse): ?><form method="post" class="lms-activity-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="create_activity"><input type="hidden" name="course_id" value="<?=$selectedCourse?>"><label><span>Type</span><select name="item_type"><option>Material</option><option>Assignment</option><option>Quiz</option></select></label><label class="lms-activity-title"><span>Title</span><input name="title" maxlength="180" required></label><label><span>Due date</span><input type="date" name="due_date"></label><label class="lms-activity-description"><span>Instructions or material details</span><textarea name="description" rows="3"></textarea></label><button class="lms-button" type="submit">Publish activity</button></form><?php endif; ?>
        <?php if(!$activities): ?><p class="lms-empty">No learning activities have been published for this course yet.</p><?php else: ?><div class="lms-activity-list">
        <?php foreach($activities as $activity): ?><article class="lms-activity"><div class="lms-activity-mark <?=strtolower(e($activity['item_type']))?>" aria-hidden="true"><?= $activity['item_type']==='Assignment'?'A':($activity['item_type']==='Quiz'?'Q':'M') ?></div><div class="lms-activity-content"><div class="lms-activity-top"><span class="lms-type-label"><?=e($activity['item_type'])?></span><?php if($activity['due_date']): ?><time>Due <?=e(date('M j, Y',strtotime($activity['due_date'])))?></time><?php endif; ?></div><h3><?=e($activity['title'])?></h3><?php if($activity['description']): ?><p><?=nl2br(e($activity['description']))?></p><?php endif; ?>
        <?php if($isStudent&&$activity['item_type']==='Assignment'): ?><form method="post" class="lms-submit-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="submit_assignment"><input type="hidden" name="item_id" value="<?=(int)$activity['id']?>"><input type="hidden" name="course_id" value="<?=$selectedCourse?>"><label><span>Your work</span><textarea name="submission_text" rows="3" placeholder="Write your response or summarize your work"></textarea></label><label><span>Optional link</span><input type="url" name="submission_url" maxlength="1000" placeholder="https://"></label><button class="lms-button" type="submit">Submit assignment</button></form><?php endif; ?></div></article><?php endforeach; ?>
        </div><?php endif; ?>
    </section>

    <?php if($canManageSelectedCourse||$isStudent): ?><section class="lms-submissions"><div class="lms-section-title"><div><p class="eyebrow red">ASSESSMENT RECORDS</p><h2><?= $canManageSelectedCourse?'Assignment submissions':'My submissions' ?></h2></div><span class="lms-count"><?=count($submissions)?> attempts</span></div>
        <?php if(!$submissions): ?><p class="lms-empty">No assignment submissions have been recorded for this course.</p><?php else: ?><div class="lms-submission-list">
        <?php foreach($submissions as $submission): ?><article class="lms-submission"><div class="lms-submission-heading"><div><strong><?=e($submission['assignment_title'])?></strong><?php if($canTeach): ?><span><?=e($submission['full_name'])?></span><?php endif; ?></div><span class="lms-status <?=strtolower(e($submission['status']))?>"><?=e($submission['status'])?></span></div><div class="lms-submission-meta"><span>Attempt <?= (int)$submission['attempt_number'] ?></span><time><?=e(date('M j, Y g:i A',strtotime($submission['submitted_at'])))?></time><?php if($submission['score']!==null): ?><strong><?=e(number_format((float)$submission['score'],2))?> / 100</strong><?php endif; ?></div>
            <?php if($submission['submission_text']!==''): ?><p class="lms-submission-text"><?=nl2br(e($submission['submission_text']))?></p><?php endif; ?><?php if($submission['submission_url']): ?><a class="lms-submission-link" href="<?=e($submission['submission_url'])?>" target="_blank" rel="noopener noreferrer">Open submitted link <span aria-hidden="true">&#8599;</span></a><?php endif; ?><?php if($submission['feedback']): ?><p class="lms-feedback"><strong>Instructor feedback</strong><?=nl2br(e($submission['feedback']))?></p><?php endif; ?>
            <?php if($canManageSelectedCourse): ?><form method="post" class="lms-grade-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="grade_submission"><input type="hidden" name="submission_id" value="<?=(int)$submission['id']?>"><input type="hidden" name="course_id" value="<?=$selectedCourse?>"><label><span>Score / 100</span><input type="number" name="score" min="0" max="100" step="0.01" value="<?= $submission['score']!==null?e($submission['score']):'' ?>" required></label><label class="lms-feedback-input"><span>Feedback</span><input name="feedback" maxlength="2000" value="<?=e($submission['feedback']??'')?>"></label><button class="lms-button secondary" type="submit">Save grade</button></form><?php endif; ?>
        </article><?php endforeach; ?></div><?php endif; ?>
    </section><?php endif; ?>
    <?php elseif($activeCourse&&$isStudent): ?><p class="lms-enrollment-notice">Enroll in <?=e($activeCourse['course_code'])?> to view course materials and assignments.</p><?php endif; ?>
    <footer>BSU Connect · Learning activity and submission records</footer>
</main></div>
</body></html>