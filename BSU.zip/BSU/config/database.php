<?php
declare(strict_types=1);

class Database {
    private static ?PDO $connection = null;

    public static function connect(): PDO {
        if (self::$connection instanceof PDO) return self::$connection;
        $host = '127.0.0.1';
        $dbname = 'bsu_integrated_system';
        $username = 'root';
        $password = ''; // Default XAMPP MySQL password. Update if yours is different.
        self::$connection = new PDO(
            "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
            $username,
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        return self::$connection;
    }
}
