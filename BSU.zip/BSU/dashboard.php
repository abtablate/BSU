<?php
require_once __DIR__.'/config/bootstrap.php'; require_login();
$user=current_user();
$allowedSystems=accessible_systems();
$students=['total'=>0,'enrolled'=>0,'pending'=>0];
$learning=['courses'=>0,'activities'=>0,'upcoming'=>0];
$books=['titles'=>0,'available'=>0];
$loans=['active'=>0,'overdue'=>0,'today'=>0];
$security=['events'=>0,'incidents'=>0];
$aid=['total'=>0,'pending'=>0,'approved'=>0];
$dining=['transactions'=>0,'amount'=>0];
if(in_array('students',$allowedSystems,true))$students=$pdo->query("SELECT COUNT(*) AS total, COALESCE(SUM(enrollment_status='Enrolled'),0) AS enrolled, COALESCE(SUM(enrollment_status='Pending'),0) AS pending FROM students")->fetch();
if(in_array('lms',$allowedSystems,true))$learning=$pdo->query("SELECT (SELECT COUNT(*) FROM courses) AS courses, COUNT(*) AS activities, COALESCE(SUM(due_date>=CURRENT_DATE),0) AS upcoming FROM lms_items")->fetch();
if(in_array('library',$allowedSystems,true)){$books=$pdo->query("SELECT COUNT(*) AS titles, COALESCE(SUM(copies_available),0) AS available FROM books")->fetch();$loans=$pdo->query("SELECT COALESCE(SUM(status IN ('Borrowed','Overdue')),0) AS active, COALESCE(SUM(status='Overdue' OR (status='Borrowed' AND due_date<CURRENT_DATE)),0) AS overdue, COALESCE(SUM(borrowed_at=CURRENT_DATE),0) AS today FROM library_loans")->fetch();}
if(in_array('security',$allowedSystems,true))$security=$pdo->query("SELECT COUNT(*) AS events, COALESCE(SUM(event_type='Incident'),0) AS incidents FROM security_logs WHERE event_time>=CURRENT_DATE")->fetch();
if(in_array('aid',$allowedSystems,true))$aid=$pdo->query("SELECT COUNT(*) AS total, COALESCE(SUM(eligibility_status='Pending'),0) AS pending, COALESCE(SUM(eligibility_status='Approved'),0) AS approved FROM aid_applications")->fetch();
if(in_array('dining',$allowedSystems,true))$dining=$pdo->query("SELECT COUNT(*) AS transactions, COALESCE(SUM(transaction_amount),0) AS amount FROM dining_transactions WHERE transaction_time>=CURRENT_DATE")->fetch();
$summary=[
 ['module'=>'students','name'=>'Student Information','value'=>number_format((int)$students['total']),'unit'=>'student profiles','detail'=>number_format((int)$students['enrolled']).' enrolled · '.number_format((int)$students['pending']).' pending'],
 ['module'=>'lms','name'=>'Learning Management','value'=>number_format((int)$learning['activities']),'unit'=>'learning activities','detail'=>number_format((int)$learning['courses']).' courses · '.number_format((int)$learning['upcoming']).' upcoming'],
 ['module'=>'library','name'=>'Library Management','value'=>number_format((int)$loans['active']),'unit'=>'active loans','detail'=>number_format((int)$loans['overdue']).' overdue · '.number_format((int)$books['available']).' copies available'],
 ['module'=>'security','name'=>'Campus Security','value'=>number_format((int)$security['events']),'unit'=>'events today','detail'=>number_format((int)$security['incidents']).' incidents today'],
 ['module'=>'aid','name'=>'Financial Aid','value'=>number_format((int)$aid['pending']),'unit'=>'pending applications','detail'=>number_format((int)$aid['total']).' applications · '.number_format((int)$aid['approved']).' approved'],
 ['module'=>'dining','name'=>'Dining Services','value'=>number_format((int)$dining['transactions']),'unit'=>'transactions today','detail'=>'₱'.number_format((float)$dining['amount'],2).' total today']
];
$summary=array_values(array_filter($summary,static fn($item)=>in_array($item['module'],$allowedSystems,true)));
$serviceRoutes=['students'=>'students.php','lms'=>'lms.php','library'=>'library.php','security'=>'security.php','aid'=>'aid.php','dining'=>'dining.php'];
$activityQueries=[]; $activityParams=[];
if(in_array('lms',$allowedSystems,true)){
 if($user['role']==='student'){$activityQueries[]="SELECT 'LMS activity' AS activity,i.title AS detail,i.created_at AS happened FROM lms_items i JOIN lms_enrollments e ON e.course_id=i.course_id WHERE e.user_id=?";$activityParams[]=(int)$user['id'];}
 elseif($user['role']==='instructor'){$activityQueries[]="SELECT 'LMS activity' AS activity,i.title AS detail,i.created_at AS happened FROM lms_items i JOIN courses c ON c.id=i.course_id WHERE LOWER(TRIM(c.instructor))=LOWER(TRIM(?))";$activityParams[]=$user['full_name'];}
 else $activityQueries[]="SELECT 'LMS activity' AS activity,title AS detail,created_at AS happened FROM lms_items";
}
if(in_array('library',$allowedSystems,true))$activityQueries[]="SELECT 'Library loan' AS activity,CONCAT('Student ',student_id,' borrowed a book') AS detail,borrowed_at AS happened FROM library_loans";
if(in_array('security',$allowedSystems,true))$activityQueries[]="SELECT 'Campus security' AS activity,CONCAT(event_type,' at ',location) AS detail,event_time AS happened FROM security_logs";
if(in_array('dining',$allowedSystems,true))$activityQueries[]="SELECT 'Dining purchase' AS activity,CONCAT(purchase_description,' · ₱',FORMAT(transaction_amount,2)) AS detail,transaction_time AS happened FROM dining_transactions";
$recent=[];
if($activityQueries){$recentStmt=$pdo->prepare(implode(' UNION ALL ',$activityQueries).' ORDER BY happened DESC LIMIT 6');$recentStmt->execute($activityParams);$recent=$recentStmt->fetchAll();}
$flash=$_SESSION['flash']??null; unset($_SESSION['flash']);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard | BSU Connect</title><link rel="stylesheet" href="assets/css/style.css"></head><body class="dashboard-page">
<?php include __DIR__.'/includes/header.php'; ?>
<div class="app-shell"><?php include __DIR__.'/includes/sidebar.php'; ?><main class="main-content">
<div class="welcome-row dashboard-welcome"><div><div class="eyebrow red">BSU CONNECT / CAMPUS SERVICES</div><h1>Campus overview</h1><div class="muted">Welcome back, <?=e($user['full_name'])?>. Here is the latest system summary.</div></div><div class="dashboard-tools"><div class="date-chip"><?=date('l, F j, Y')?></div></div></div>
<?php if($flash): ?><div class="alert <?=e($flash['type'])?>"><?=e($flash['message'])?></div><?php endif; ?>
<?php $todaySystems=array_intersect(['library','security','dining'],$allowedSystems); if($todaySystems): ?><section class="dashboard-today" aria-label="Today's activity"><div class="today-heading"><div></div></div><div class="today-metrics">
<?php if(in_array('library',$todaySystems,true)): ?>
<div class="today-metric"><span class="today-marker library-marker" aria-hidden="true"></span><div><strong><?=number_format((int)$loans['today'])?></strong><span>Library loans</span></div></div>
<?php endif; if(in_array('security',$todaySystems,true)): ?>
<div class="today-metric"><span class="today-marker security-marker" aria-hidden="true"></span><div><strong><?=number_format((int)$security['events'])?></strong><span>Security events</span></div></div>
<?php endif; if(in_array('dining',$todaySystems,true)): ?>
<div class="today-metric"><span class="today-marker dining-marker" aria-hidden="true"></span><div><strong><?=number_format((int)$dining['transactions'])?></strong><span>Dining purchases</span></div></div>
<?php endif; ?>
</div></section><?php endif; ?>
<div class="dashboard-main-grid"><section class="dashboard-summary" aria-labelledby="summary-heading"><div class="section-heading"><div><div class="eyebrow red">SYSTEM STATUS</div><h2 id="summary-heading">Campus systems</h2><div class="muted">Live totals and items that may need attention.</div></div></div>
<div class="summary-list"><?php foreach($summary as $item): ?><a class="summary-row" href="<?=e($serviceRoutes[$item['module']])?>"><span class="summary-name"><?=e($item['name'])?></span><span class="summary-metric"><strong><?=e($item['value'])?></strong><small><?=e($item['unit'])?></small></span><span class="summary-detail"><?=e($item['detail'])?></span></a><?php endforeach; ?></div>
</section>
<aside class="activity-panel dashboard-activity"><div class="section-heading"><div><div class="eyebrow red">LATEST UPDATES</div><h2>Recent activity</h2></div></div>
<?php if(!$recent): ?><div class="empty-state">No activity yet. New records will appear here.</div><?php else: foreach($recent as $r): ?><div class="activity-row"><div class="activity-dot"></div><div><strong><?=e($r['activity'])?></strong><div class="activity-copy"><?=e($r['detail'])?></div><time><?=e($r['happened'])?></time></div></div><?php endforeach; endif; ?></section>
</div>
<footer>BSU Connect · Academic integration prototype · Not an official Batangas State University service</footer></main></div></body></html>
