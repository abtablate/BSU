<?php
require_once __DIR__.'/config/bootstrap.php'; require_login(); verify_csrf();
$routes=['students'=>'students.php','lms'=>'lms.php','library'=>'library.php','security'=>'security.php','aid'=>'aid.php','dining'=>'dining.php'];
if(!isset($moduleConfig) || !is_array($moduleConfig) || !isset($moduleConfig['key']) || !isset($routes[$moduleConfig['key']])){
 $legacyModule=$_GET['module']??'';
 if(isset($routes[$legacyModule])) redirect($routes[$legacyModule]);
 redirect('dashboard.php');
}
$c=$moduleConfig; $module=$c['key']; require_system_access($module); $route=$routes[$module]; $table=$c['table']; $message='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!is_admin() && !in_array($module,['students','lms','library','aid','dining','security'],true)){http_response_code(403);exit('Not allowed');}
 $values=[];
 foreach($c['fields'] as $f){$key=$f[0];$value=trim($_POST[$key]??''); $required=$f[2]==='select' || ($f[2]!=='course' && $f[3]===true); if($value==='' && $required){$message='Please complete the required fields.';break;} $values[$key]=$value===''?null:$value;}
 if(!$message){
  if(in_array($module,['aid','dining'],true)){
   $studentCheck=$pdo->prepare('SELECT 1 FROM students WHERE student_id=?');$studentCheck->execute([$values['student_id']??'']);
   if(!$studentCheck->fetchColumn()) $message='Select a valid student from the Student Information System.';
  }
  if($module==='security' && ($values['person_type']??'')==='Student'){
   $studentCheck=$pdo->prepare('SELECT 1 FROM students WHERE student_id=?');$studentCheck->execute([$values['person_id']??'']);
   if(!$studentCheck->fetchColumn()) $message='Enter a valid student ID from the Student Information System.';
  }
  if($module==='security' && !in_array($values['person_type']??'', ['Student','Employee','Visitor'], true)) $message='Select a valid person type.';
  if($module==='students' && !empty($values['user_id'])){
   $accountCheck=$pdo->prepare("SELECT 1 FROM users u LEFT JOIN students s ON s.user_id=u.id WHERE u.id=? AND u.role='student' AND s.id IS NULL");$accountCheck->execute([$values['user_id']]);
   if(!$accountCheck->fetchColumn()) $message='Choose an unlinked student login account.';
  }
 }
 if(!$message){
  if($module==='lms' && empty($values['course_id'])) $values['course_id']=null;
  if($module==='security' && empty($values['event_time'])) $values['event_time']=date('Y-m-d H:i:s');
  if($module==='dining' && empty($values['transaction_time'])) $values['transaction_time']=date('Y-m-d H:i:s');
  $cols=array_keys($values);$sql="INSERT INTO `$table` (`".implode('`,`',$cols)."`) VALUES (".implode(',',array_fill(0,count($cols),'?')).")";
    try{$stmt=$pdo->prepare($sql);$stmt->execute(array_values($values));flash('Record added successfully.');redirect($route);}catch(PDOException $ex){$message='Could not save this record. Check that the values are valid and not duplicated.';}
 }
}
if(isset($_GET['delete']) && is_admin()){
 $stmt=$pdo->prepare("DELETE FROM `$table` WHERE id=?");$stmt->execute([(int)$_GET['delete']]);flash('Record deleted.');redirect($route);
}
$select=$module==='lms'?"SELECT l.*,c.course_name FROM lms_items l LEFT JOIN courses c ON c.id=l.course_id ORDER BY l.id DESC":
 ($module==='security'?"SELECT * FROM security_logs ORDER BY id DESC":($module==='students'?"SELECT s.*,
 (SELECT COUNT(*) FROM lms_enrollments le WHERE le.user_id=s.user_id) AS lms_courses,
 (SELECT COUNT(*) FROM library_loans ll WHERE ll.student_id=s.student_id AND ll.archived_at IS NULL) AS library_loans,
 (SELECT COUNT(*) FROM security_logs sl WHERE sl.person_id=s.student_id AND sl.person_type='Student') AS security_events,
 (SELECT COUNT(*) FROM aid_applications aa WHERE aa.student_id=s.student_id) AS aid_applications,
 (SELECT COUNT(*) FROM dining_transactions dt WHERE dt.student_id=s.student_id) AS dining_transactions
 FROM students s ORDER BY s.id DESC":"SELECT * FROM `$table` ORDER BY id DESC"));
$rows=$pdo->query($select)->fetchAll();
$securityEntriesToday=0;$securityExitsToday=0;
if($module==='security')foreach($rows as $securityRow){if(substr($securityRow['event_time'],0,10)===date('Y-m-d')){if($securityRow['event_type']==='Entry')$securityEntriesToday++;if($securityRow['event_type']==='Exit')$securityExitsToday++;}}
$courses=$module==='lms'?$pdo->query('SELECT id,course_code,course_name FROM courses ORDER BY course_code')->fetchAll():[];
 $studentProfiles=in_array($module,['aid','dining','security'],true)?$pdo->query('SELECT student_id,full_name FROM students ORDER BY full_name')->fetchAll():[];
$studentAccounts=$module==='students'?$pdo->query("SELECT u.id,u.full_name,u.email FROM users u LEFT JOIN students s ON s.user_id=u.id WHERE u.role='student' AND s.id IS NULL ORDER BY u.full_name")->fetchAll():[];
$flash=$_SESSION['flash']??null;unset($_SESSION['flash']);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($c['title'])?> | BSU Connect</title><link rel="stylesheet" href="assets/css/style.css"></head><body><?php include __DIR__.'/includes/header.php';?><div class="app-shell"><?php include __DIR__.'/includes/sidebar.php';?><main class="main-content">
<?php if($flash):?><div class="alert success" role="status"><?=e($flash['message'])?></div><?php endif;?>
<?php if($module==='security'):?><header class="security-heading"><div><p class="security-kicker">CAMPUS ACCESS CONTROL</p><h1>Security register</h1><p class="security-subtitle"><?=e($c['subtitle'])?> · Track entry, exit, and incidents by person type.</p></div><div class="security-status"><span></span> SECURITY DESK</div></header><section class="security-overview" aria-label="Today's access activity"><div><span>Entries today</span><strong><?=$securityEntriesToday?></strong></div><div><span>Exits today</span><strong><?=$securityExitsToday?></strong></div><div><span>Total records</span><strong><?=count($rows)?></strong></div></section><?php endif;?>
<div class="module-toolbar"><button class="btn primary add-record-button" type="button" id="openRecordDialog"><span aria-hidden="true">+</span> Add new record</button></div>
<dialog class="record-dialog" id="recordDialog" aria-labelledby="recordDialogTitle">
<div class="record-dialog-header"><div><h2 id="recordDialogTitle">Add new record</h2><p>Enter the details below, then save the record.</p></div><button class="dialog-close" type="button" id="closeRecordDialog" aria-label="Close dialog">&times;</button></div>
<?php if($message):?><div class="alert error" role="alert"><?=e($message)?></div><?php endif;?>
<form method="post" action="<?=e($route)?>" class="record-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><div class="record-form-grid">
<?php foreach($c['fields'] as $f):[$key,$label,$type,$extra]=$f;?><div class="record-field"><label for="<?=e($key)?>"><?=e($label)?><?php if($extra===true || $type==='select'):?><span class="required">*</span><?php endif;?></label>
<?php if($type==='select'):?><select id="<?=e($key)?>" name="<?=e($key)?>" required><?php foreach($extra as $opt):?><option value="<?=e($opt)?>"><?=e($opt)?></option><?php endforeach;?></select>
<?php elseif($type==='course'):?><select id="course_id" name="course_id"><option value="">Select course</option><?php foreach($courses as $course):?><option value="<?=$course['id']?>"><?=e($course['course_code'].' — '.$course['course_name'])?></option><?php endforeach;?></select>
<?php elseif($type==='student'):?><select id="<?=e($key)?>" name="<?=e($key)?>" required><option value="">Select student</option><?php foreach($studentProfiles as $student):?><option value="<?=e($student['student_id'])?>"><?=e($student['student_id'].' — '.$student['full_name'])?></option><?php endforeach;?></select>
<?php elseif($type==='user'):?><select id="<?=e($key)?>" name="<?=e($key)?>"><option value="">No login account linked</option><?php foreach($studentAccounts as $account):?><option value="<?=$account['id']?>"><?=e($account['full_name'].' — '.$account['email'])?></option><?php endforeach;?></select>
<?php elseif($type==='person'):?><select id="personStudentId" name="person_id" required><option value="">Select student</option><?php foreach($studentProfiles as $student):?><option value="<?=e($student['student_id'])?>"><?=e($student['student_id'].' — '.$student['full_name'])?></option><?php endforeach;?></select><input id="personEmployeeId" type="text" name="person_id" placeholder="Employee ID" required disabled><input id="personVisitorId" type="text" name="person_id" placeholder="Visitor pass number" required disabled>
<?php elseif($type==='textarea'):?><textarea id="<?=e($key)?>" name="<?=e($key)?>" rows="3"></textarea>
<?php elseif($module==='security' && $key==='event_time'):?><input id="event_time" type="datetime-local" name="event_time" value="<?=e($_POST['event_time']??date('Y-m-d\\TH:i'))?>" required>
<?php else:?><input id="<?=e($key)?>" type="<?=e($type)?>" name="<?=e($key)?>" <?=($extra===true?'required':'')?> <?=($type==='number'?'step="0.01" min="0"':'')?>><?php endif;?></div><?php endforeach;?>
</div><div class="record-dialog-actions"><button class="dialog-cancel" type="button" id="cancelRecordDialog">Cancel</button><button class="btn primary" type="submit">Save record</button></div></form>
</dialog>
<?php if($module==='security'):?><div class="security-lists"><?php foreach(['Student','Employee','Visitor'] as $personType):$listId='security'.ucfirst(strtolower($personType)).'List';$personRows=array_values(array_filter($rows,static fn($record)=>$record['person_type']===$personType));?><section class="security-list"><div class="security-list-heading"><div><span class="security-list-mark <?=strtolower($personType)?>"></span><h2><?=$personType?> access</h2><span class="security-count"><?=count($personRows)?></span></div><input class="search-input" aria-label="Search <?=$personType?> logs" placeholder="Search <?=$personType?> logs..." oninput="filterSecurityList('<?=$listId?>',this.value)"></div><div class="table-scroll"><table id="<?=$listId?>"><thead><tr><?php foreach($c['columns'] as $label):?><th><?=e($label)?></th><?php endforeach;?><?php if(is_admin()):?><th>Action</th><?php endif;?></tr></thead><tbody><?php foreach($personRows as $row):?><tr><?php foreach($c['columns'] as $key=>$label):?><td><?php $v=$row[$key]??'';if($key==='event_type'):?><span class="security-event <?=strtolower(e($v))?>"><?=e($v)?></span><?php elseif($key==='event_time'):echo e(date('M j, Y · g:i A',strtotime($v)));else:echo e($v);endif;?></td><?php endforeach;?><?php if(is_admin()):?><td><a class="delete-link" onclick="return confirm('Delete this record?')" href="<?=e($route)?>?delete=<?=$row['id']?>">Delete</a></td><?php endif;?></tr><?php endforeach;?><tr class="security-empty" <?=count($personRows)?'hidden':''?>><td colspan="<?=count($c['columns'])+(is_admin()?1:0)?>" class="empty-state">No <?=e(strtolower($personType))?> access records.</td></tr></tbody></table></div></section><?php endforeach;?></div><?php else:?>
<section class="module-layout module-records"><div class="table-panel"><div class="table-head"><div><h2>Records</h2><p class="muted">Latest saved entries</p></div><input id="tableSearch" class="search-input" placeholder="Search records..." oninput="filterRows()"></div>
<div class="table-scroll"><table id="recordsTable"><thead><tr><?php foreach($c['columns'] as $label):?><th><?=e($label)?></th><?php endforeach;?><?php if(is_admin()):?><th>Action</th><?php endif;?></tr></thead><tbody>
<?php foreach($rows as $row):?><tr><?php foreach($c['columns'] as $key=>$label):?><td><?php $v=$row[$key]??'';if($key==='lms_courses'&&empty($row['user_id']))echo 'Not linked';elseif(in_array($key,['transaction_amount','meal_balance','fine'],true))echo '₱'.number_format((float)$v,2);elseif(in_array($key,['lms_courses','library_loans','security_events','aid_applications','dining_transactions'],true))echo number_format((int)$v);else echo e($v);?></td><?php endforeach;?><?php if(is_admin()):?><td><a class="delete-link" onclick="return confirm('Delete this record?')" href="<?=e($route)?>?delete=<?=$row['id']?>">Delete</a></td><?php endif;?></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="<?=count($c['columns'])+1?>" class="empty-state">No records yet. Select “Add new record” to create one.</td></tr><?php endif;?></tbody></table></div></div></section><?php endif;?>
<footer>BSU Connect · Demonstration data only · Not an official BSU platform</footer></main></div><script>
function filterRows(){const q=document.getElementById('tableSearch').value.toLowerCase();document.querySelectorAll('#recordsTable tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')}
function filterSecurityList(id,query){const table=document.getElementById(id);const rows=[...table.querySelectorAll('tbody tr:not(.security-empty)')];const term=query.toLowerCase();let visible=0;rows.forEach(row=>{const match=row.innerText.toLowerCase().includes(term);row.hidden=!match;if(match)visible++});table.querySelector('.security-empty').hidden=visible>0}
const recordDialog=document.getElementById('recordDialog');
document.getElementById('openRecordDialog').addEventListener('click',()=>recordDialog.showModal());
document.getElementById('closeRecordDialog').addEventListener('click',()=>recordDialog.close());
document.getElementById('cancelRecordDialog').addEventListener('click',()=>recordDialog.close());
recordDialog.addEventListener('click',event=>{if(event.target===recordDialog)recordDialog.close()});
const personType=document.getElementById('person_type');
if(personType){const studentId=document.getElementById('personStudentId');const employeeId=document.getElementById('personEmployeeId');const visitorId=document.getElementById('personVisitorId');const syncPersonFields=()=>{const isStudent=personType.value==='Student';const isEmployee=personType.value==='Employee';studentId.disabled=!isStudent;studentId.required=isStudent;employeeId.disabled=!isEmployee;employeeId.required=isEmployee;visitorId.disabled=personType.value!=='Visitor';visitorId.required=personType.value==='Visitor'};personType.addEventListener('change',syncPersonFields);syncPersonFields()}
<?php if($message):?>recordDialog.showModal();<?php endif;?>
</script></body></html>
