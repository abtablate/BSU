<?php
$moduleConfig = [
    'key' => 'aid',
    'title' => 'Financial Aid System',
    'subtitle' => 'Track scholarships, grants and student eligibility applications.',
    'table' => 'aid_applications',
    'fields' => [
        ['student_id', 'Student', 'student', true],
        ['scholarship', 'Scholarship', 'text', true],
        ['grant_name', 'Grant', 'text', false],
        ['academic_standing', 'Academic standing', 'text', false],
        ['eligibility_status', 'Eligibility status', 'select', ['Pending', 'Eligible', 'Not eligible', 'Approved', 'Rejected']],
        ['application_date', 'Application date', 'date', true],
    ],
    'columns' => [
        'student_id' => 'Student ID',
        'scholarship' => 'Scholarship',
        'grant_name' => 'Grant',
        'eligibility_status' => 'Eligibility',
        'application_date' => 'Applied',
    ],
];
require __DIR__ . '/module.php';