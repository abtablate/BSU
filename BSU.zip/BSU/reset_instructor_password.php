
<?php
require_once __DIR__ . '/config/bootstrap.php';

$email = 'instructor@bsu.edu.ph';
$newPassword = 'Instructor123';

// Find the existing instructor
$stmt = $pdo->prepare(
    "SELECT id FROM users
     WHERE email = ? AND role = 'instructor'"
);
$stmt->execute([$email]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    exit("Instructor account not found!");
}

// Generate a new bcrypt password hash
$newHash = password_hash($newPassword, PASSWORD_DEFAULT);

// Update the existing account
$update = $pdo->prepare(
    "UPDATE users SET password_hash = ? WHERE id = ?"
);

$update->execute([$newHash, $user['id']]);

// Verify the newly saved password
$check = $pdo->prepare(
    "SELECT password_hash FROM users WHERE id = ?"
);
$check->execute([$user['id']]);

$savedHash = $check->fetchColumn();

if (password_verify($newPassword, $savedHash)) {
    echo "SUCCESS! Instructor password reset.";
} else {
    echo "ERROR! Password verification failed.";
}
