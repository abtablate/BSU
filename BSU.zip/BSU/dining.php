<?php
$moduleConfig = [
    'key' => 'dining',
    'title' => 'Dining Services',
    'subtitle' => 'Record campus-card meal purchases and remaining balances.',
    'table' => 'dining_transactions',
    'fields' => [
        ['student_id', 'Student', 'student', true],
        ['campus_card_number', 'Campus card number', 'text', false],
        ['meal_plan', 'Meal plan', 'text', false],
        ['meal_balance', 'Meal balance (₱)', 'number', false],
        ['purchase_description', 'Food purchase', 'text', true],
        ['transaction_amount', 'Amount (₱)', 'number', true],
        ['transaction_time', 'Transaction date/time', 'datetime-local', false],
    ],
    'columns' => [
        'student_id' => 'Student ID',
        'campus_card_number' => 'Campus card',
        'purchase_description' => 'Purchase',
        'transaction_amount' => 'Amount',
        'meal_balance' => 'Balance',
        'transaction_time' => 'Date/time',
    ],
];
require __DIR__ . '/module.php';