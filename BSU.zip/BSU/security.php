<?php
$moduleConfig = [
    'key' => 'security',
    'title' => 'Campus Security System',
    'subtitle' => 'Campus access register',
    'table' => 'security_logs',
    'fields' => [
        ['person_id', 'Student ID / Employee ID / Visitor pass', 'person', true],
        ['person_type', 'Person type', 'select', ['Student', 'Employee', 'Visitor']],
        ['location', 'Building / Room', 'text', true],
        ['event_type', 'Event type', 'select', ['Entry', 'Exit', 'Incident']],
        ['event_details', 'Details / CCTV reference', 'textarea', false],
        ['event_time', 'Date and time', 'datetime-local', false],
    ],
    'columns' => [
        'person_id' => 'Person ID / Pass',
        'location' => 'Location',
        'event_type' => 'Event',
        'event_time' => 'Date & time',
    ],
];
require __DIR__ . '/module.php';