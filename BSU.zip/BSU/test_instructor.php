
<?php
require_once __DIR__ . '/config/bootstrap.php';

$email = 'instructor@bsu.edu.ph';
$password = 'Instructor123';

echo "<h2>Instructor Login Diagnostic</h2>";

// 1. Check connected database
$db = $pdo->query("SELECT DATABASE()")->fetchColumn();
echo "Connected database: " . htmlspecialchars($db) . "<br>";

// 2. Find instructor account
$stmt = $pdo->prepare(
    "SELECT id, full_name, email, password_hash, role
     FROM users
     WHERE email = ?"
);
$stmt->execute([$email]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    exit("ERROR: Instructor account not found in this database.");
}

echo "Account found: YES<br>";
echo "Name: " . htmlspecialchars($user['full_name']) . "<br>";
echo "Role: " . htmlspecialchars($user['role']) . "<br>";

// 3. Test password
if (password_verify($password, $user['password_hash'])) {
    echo "<h3 style='color:green'>PASSWORD MATCHES!</h3>";
} else {
    echo "<h3 style='color:red'>PASSWORD DOES NOT MATCH.</h3>";
}

// 4. Check hash format
echo "Hash algorithm: " .
    htmlspecialchars(password_get_info($user['password_hash'])['algoName']);
