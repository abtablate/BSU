<?php
require_once __DIR__.'/config/bootstrap.php';
if (!empty($_SESSION['user'])) redirect('dashboard.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $stmt=$pdo->prepare('SELECT id,full_name,email,password_hash,role FROM users WHERE email=?');
    $stmt->execute([trim($_POST['email'] ?? '')]); $user=$stmt->fetch();
    if ($user && password_verify($_POST['password'] ?? '',$user['password_hash'])) {
        unset($user['password_hash']); $_SESSION['user']=$user; redirect('dashboard.php');
    } else $error='Incorrect email or password. Please try again.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#8d1528">
    <title>Sign in | BSU Connect</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <main class="login-wrap">
        <section class="login-brand" aria-label="Batangas State University">
            <div class="login-logo-frame">
                <img class="login-logo" src="images/logo-transparent.png" alt="Official seal of Batangas State University">
            </div>
            <p class="login-brand-kicker">The National Engineering University</p>
            <h1>Batangas State University</h1>
            <p class="login-intro">Your campus services, learning resources, and university community in one place.</p>
        </section>
        <section class="login-card" aria-labelledby="login-heading">
            <header class="login-header">
                <p class="login-kicker">UNIVERSITY ACCOUNT</p>
                <h2 id="login-heading">Welcome back</h2>
                <p class="muted">Sign in with your university account to continue.</p>
            </header>
            <?php if ($error): ?>
                <div class="alert error" role="alert"><?=e($error)?></div>
            <?php endif; ?>
            <form method="post" class="login-form" autocomplete="off">
                <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
                <div class="login-field">
                    <label for="email">Email address</label>
                    <input id="email" type="email" name="email" placeholder="name@bsu.edu.ph" autocomplete="off" autocapitalize="none" spellcheck="false" readonly required>
                </div>
                <div class="login-field">
                    <label for="password">Password</label>
                    <div class="password-control">
                        <input id="password" type="password" name="password" placeholder="Enter your password" autocomplete="off" readonly required>
                        <button class="password-toggle" type="button" aria-label="Show password" aria-controls="password" aria-pressed="false">Show</button>
                    </div>
                </div>
                <button class="login-submit" type="submit">Sign in</button>
            </form>
            <div class="login-security"><span class="login-security-mark" aria-hidden="true"></span> Secure sign-in to BSU Connect</div>
        </section>
    </main>
    <script>
        document.querySelectorAll('.login-form .login-field input').forEach((input) => {
            const enableInput = () => {
                input.removeAttribute('readonly');
                input.value = '';
            };
            input.addEventListener('focus', enableInput, { once: true });
            input.addEventListener('pointerdown', enableInput, { once: true });
            input.addEventListener('keydown', enableInput, { once: true });
            document.querySelector(`label[for="${input.id}"]`).addEventListener('pointerdown', enableInput, { once: true });
            if (document.activeElement === input) enableInput();
        });
        window.addEventListener('pageshow', () => {
            const activeInput = document.activeElement;
            if (activeInput.matches('.login-form .login-field input[readonly]')) {
                activeInput.removeAttribute('readonly');
                activeInput.value = '';
            }
        });

        const passwordInput = document.getElementById('password');
        const passwordToggle = document.querySelector('.password-toggle');
        passwordToggle.addEventListener('click', () => {
            const isVisible = passwordInput.type === 'text';
            passwordInput.type = isVisible ? 'password' : 'text';
            passwordToggle.textContent = isVisible ? 'Show' : 'Hide';
            passwordToggle.setAttribute('aria-label', isVisible ? 'Show password' : 'Hide password');
            passwordToggle.setAttribute('aria-pressed', String(!isVisible));
        });
    </script>
</body>
</html>
