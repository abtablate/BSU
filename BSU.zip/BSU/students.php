<?php
$moduleConfig = [
    'key' => 'students',
    'title' => 'Student Information System',
    'subtitle' => 'Manage student identity, enrollment and academic profile.',
    'table' => 'students',
    'fields' => [
        ['student_id', 'Student ID', 'text', true],
        ['full_name', 'Student name', 'text', true],
        ['user_id', 'LMS login account', 'user', false],
        ['contact', 'Contact number', 'text', false],
        ['program', 'Program / Course', 'text', false],
        ['year_level', 'Year level', 'text', false],
        ['section', 'Section', 'text', false],
        ['enrollment_status', 'Enrollment status', 'select', ['Enrolled', 'Pending', 'Inactive']],
        ['academic_records', 'Academic records', 'textarea', false],
    ],
    'columns' => [
        'student_id' => 'Student ID',
        'full_name' => 'Student name',
        'lms_courses' => 'LMS courses',
        'library_loans' => 'Library loans',
        'security_events' => 'Security events',
        'aid_applications' => 'Aid applications',
        'dining_transactions' => 'Dining transactions',
        'program' => 'Program',
        'year_level' => 'Year',
        'enrollment_status' => 'Status',
    ],
];
require __DIR__ . '/module.php';