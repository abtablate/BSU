-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2026 at 05:07 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bsu_integrated_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `aid_applications`
--

CREATE TABLE `aid_applications` (
  `id` int(11) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `scholarship` varchar(150) NOT NULL,
  `grant_name` varchar(150) DEFAULT NULL,
  `academic_standing` varchar(100) DEFAULT NULL,
  `eligibility_status` enum('Pending','Eligible','Not eligible','Approved','Rejected') DEFAULT 'Pending',
  `application_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `isbn` varchar(40) DEFAULT NULL,
  `title` varchar(180) NOT NULL,
  `author` varchar(120) DEFAULT NULL,
  `copies_total` int(11) NOT NULL DEFAULT 1,
  `copies_available` int(11) NOT NULL DEFAULT 1,
  `archived_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `isbn`, `title`, `author`, `copies_total`, `copies_available`, `archived_at`) VALUES
(1, '9780132350884', 'Clean Code', 'Robert C. Martin', 5, 4, NULL),
(2, '9781492052203', 'Learning PHP, MySQL & JavaScript', 'Robin Nixon', 3, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `book_reservations`
--

CREATE TABLE `book_reservations` (
  `id` int(11) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `book_id` int(11) NOT NULL,
  `reserved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Ready','Cancelled') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(30) NOT NULL,
  `course_name` varchar(150) NOT NULL,
  `instructor` varchar(120) DEFAULT NULL,
  `schedule` varchar(120) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_name`, `instructor`, `schedule`, `created_at`) VALUES
(1, 'IT401', 'Systems Integration and Architecture', 'Prof. Santos', 'Mon/Wed 10:00 AM', '2026-11-03 14:13:42'),
(2, 'IT402', 'Web Development', 'Prof. Reyes', 'Tue/Thu 1:00 PM', '2026-11-03 14:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `dining_transactions`
--

CREATE TABLE `dining_transactions` (
  `id` int(11) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `campus_card_number` varchar(60) DEFAULT NULL,
  `meal_plan` varchar(100) DEFAULT NULL,
  `meal_balance` decimal(10,2) DEFAULT 0.00,
  `purchase_description` varchar(180) NOT NULL,
  `transaction_amount` decimal(10,2) NOT NULL,
  `transaction_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dining_transactions`
--

INSERT INTO `dining_transactions` (`id`, `student_id`, `campus_card_number`, `meal_plan`, `meal_balance`, `purchase_description`, `transaction_amount`, `transaction_time`) VALUES
(1, '23456781', '235241111214', 'afagawgawgw', 100.00, 'Daeng na aso', 200.00, '2026-11-04 08:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `library_loans`
--

CREATE TABLE `library_loans` (
  `id` int(11) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrowed_at` date NOT NULL,
  `due_date` date NOT NULL,
  `returned_at` date DEFAULT NULL,
  `fine` decimal(9,2) NOT NULL DEFAULT 0.00,
  `status` enum('Borrowed','Returned','Overdue') DEFAULT 'Borrowed',
  `archived_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `library_loans`
--

INSERT INTO `library_loans` (`id`, `student_id`, `book_id`, `borrowed_at`, `due_date`, `returned_at`, `fine`, `status`, `archived_at`) VALUES
(2, '23-123456', 1, '2026-11-14', '2026-11-14', '2026-11-16', 20.00, 'Returned', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lms_enrollments`
--

CREATE TABLE `lms_enrollments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `enrolled_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lms_enrollments`
--

INSERT INTO `lms_enrollments` (`id`, `user_id`, `course_id`, `enrolled_at`) VALUES
(2, 2, 1, '2026-11-04 14:37:40');

-- --------------------------------------------------------

--
-- Table structure for table `lms_items`
--

CREATE TABLE `lms_items` (
  `id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `item_type` enum('Material','Assignment','Quiz') NOT NULL,
  `title` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lms_results`
--

CREATE TABLE `lms_results` (
  `id` int(11) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `lms_item_id` int(11) NOT NULL,
  `score` decimal(7,2) DEFAULT NULL,
  `submission_status` varchar(40) DEFAULT 'Not submitted',
  `submitted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lms_submissions`
--

CREATE TABLE `lms_submissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lms_item_id` int(11) NOT NULL,
  `attempt_number` int(11) NOT NULL,
  `submission_text` longtext NOT NULL,
  `submission_url` varchar(1000) DEFAULT NULL,
  `status` enum('Submitted','Late','Graded') NOT NULL DEFAULT 'Submitted',
  `score` decimal(7,2) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `graded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `security_logs`
--

CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL,
  `person_id` varchar(40) NOT NULL,
  `person_type` enum('Student','Employee','Visitor') DEFAULT 'Student',
  `location` varchar(150) NOT NULL,
  `event_type` enum('Entry','Exit','Incident') NOT NULL,
  `event_details` text DEFAULT NULL,
  `event_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_logs`
--

INSERT INTO `security_logs` (`id`, `person_id`, `person_type`, `location`, `event_type`, `event_details`, `event_time`) VALUES
(2, '123432413', 'Visitor', '214', 'Entry', NULL, '2026-11-04 14:38:00'),
(3, '12435463425351', 'Employee', 'CCST', 'Entry', NULL, '2026-11-04 14:39:00');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(40) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(120) NOT NULL,
  `contact` varchar(40) DEFAULT NULL,
  `program` varchar(120) DEFAULT NULL,
  `year_level` varchar(20) DEFAULT NULL,
  `section` varchar(40) DEFAULT NULL,
  `enrollment_status` enum('Enrolled','Pending','Inactive') DEFAULT 'Enrolled',
  `academic_records` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_id`, `user_id`, `full_name`, `contact`, `program`, `year_level`, `section`, `enrollment_status`, `academic_records`, `created_at`) VALUES
(3, '23-123456', NULL, 'HELLO', '09876543212', 'IT', '4', 'C', 'Enrolled', NULL, '2026-11-14 04:19:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `email` varchar(160) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','student','instructor','staff') NOT NULL DEFAULT 'student',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password_hash`, `role`, `created_at`) VALUES
(1, 'BSU Administrator', 'admin@bsu.edu.ph', '$2y$10$YnYd9sFu9CZwUdhmiwJk4egbRCWdu7CxKyq3kpbZqi0hAjZ1FTDTC', 'admin', '2026-11-03 14:13:42'),
(2, 'Juan Dela Cruz', 'student@bsu.edu.ph', '$2y$10$YnYd9sFu9CZwUdhmiwJk4egbRCWdu7CxKyq3kpbZqi0hAjZ1FTDTC', 'student', '2026-11-03 14:13:42'),
(3, 'BSU Instructor', 'instructor@bsu.edu.ph', '$2y$10$RdOfOkJPhM.zTj75f6EvQ.AfUev6XkCKjtbl5HnYUr5/T02AIm3XS', 'instructor', '2026-11-03 14:13:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aid_applications`
--
ALTER TABLE `aid_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_reservations`
--
ALTER TABLE `book_reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `course_code` (`course_code`);

--
-- Indexes for table `dining_transactions`
--
ALTER TABLE `dining_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `library_loans`
--
ALTER TABLE `library_loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `lms_enrollments`
--
ALTER TABLE `lms_enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_lms_enrollment` (`user_id`,`course_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `lms_items`
--
ALTER TABLE `lms_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `lms_results`
--
ALTER TABLE `lms_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lms_item_id` (`lms_item_id`);

--
-- Indexes for table `lms_submissions`
--
ALTER TABLE `lms_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_lms_submission_item_user` (`lms_item_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `security_logs`
--
ALTER TABLE `security_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aid_applications`
--
ALTER TABLE `aid_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `book_reservations`
--
ALTER TABLE `book_reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dining_transactions`
--
ALTER TABLE `dining_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `library_loans`
--
ALTER TABLE `library_loans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lms_enrollments`
--
ALTER TABLE `lms_enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lms_items`
--
ALTER TABLE `lms_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `lms_results`
--
ALTER TABLE `lms_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lms_submissions`
--
ALTER TABLE `lms_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `security_logs`
--
ALTER TABLE `security_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `book_reservations`
--
ALTER TABLE `book_reservations`
  ADD CONSTRAINT `book_reservations_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Constraints for table `library_loans`
--
ALTER TABLE `library_loans`
  ADD CONSTRAINT `library_loans_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`);

--
-- Constraints for table `lms_enrollments`
--
ALTER TABLE `lms_enrollments`
  ADD CONSTRAINT `lms_enrollments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lms_enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lms_items`
--
ALTER TABLE `lms_items`
  ADD CONSTRAINT `lms_items_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `lms_results`
--
ALTER TABLE `lms_results`
  ADD CONSTRAINT `lms_results_ibfk_1` FOREIGN KEY (`lms_item_id`) REFERENCES `lms_items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lms_submissions`
--
ALTER TABLE `lms_submissions`
  ADD CONSTRAINT `lms_submissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lms_submissions_ibfk_2` FOREIGN KEY (`lms_item_id`) REFERENCES `lms_items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
