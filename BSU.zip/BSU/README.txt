BSU CONNECT — PHP + MySQL LOCALHOST PROJECT
===========================================

ABOUT
This is a student-built academic prototype based on the six campus systems in your Group 3 presentation:
1. Student Information System
2. Learning Management System
3. Library Management System
4. Campus Security System
5. Financial Aid System
6. Dining Services

It provides one login and a unified dashboard with separate modules and a shared MySQL database.
It is NOT an official Batangas State University system and is not connected to BSU's real systems.

REQUIREMENTS
- XAMPP (Apache + MySQL)
- Visual Studio Code
- PHP 8.0+ recommended
- MySQL / phpMyAdmin

INSTALLATION
1. Extract the ZIP file.
2. Copy the folder "BSU_Integrated_Campus_System" into:
   C:\xampp\htdocs\
3. Open XAMPP Control Panel and start Apache and MySQL.
4. Open phpMyAdmin:
   http://localhost/phpmyadmin
5. Choose Import, select the project's database.sql, then click Import/Go.
   The SQL creates the database named bsu_integrated_system.
6. Open the project folder in Visual Studio Code.
7. If your MySQL root password is not blank, edit config/database.php and update $password.
8. Visit:
   http://localhost/BSU_Integrated_Campus_System/

DEMO LOGIN
Administrator:
  Email: admin@bsu.edu.ph
  Password: password

Student:
  Email: student@bsu.edu.ph
  Password: password

Instructor:
  Email: instructor@bsu.edu.ph
  Password: Instructor123

FEATURES
- Responsive dashboard and six campus service modules
- SIS profiles show linked record counts for LMS, library, campus security, financial aid and dining
- Student-based service records use students selected from the SIS roster; LMS counts require a linked student login account
- Add and view records for each module
- Admin can delete records
- Search within module tables
- Recent activity feed
- Prepared SQL statements and password hashing
- CSRF token validation on forms

IMPORTANT NOTES / LIMITATIONS
- This is a working classroom prototype, not a production-ready university platform.
- The five service connections use this project's shared local database; they are not live integrations with university systems.
- It does not connect to BSU's actual Student Information, LMS, library, security, aid or dining databases.
- The PPT lists data elements but does not specify APIs, authentication policies, integration middleware, or detailed workflows. Those need to be confirmed with BSU before a real integration.
- The library module currently manages the book catalogue; the database also includes loan and reservation tables for the next development phase.
- The LMS module manages courses' materials, assignments and quizzes; quiz grading/submission workflows are not fully implemented.
- Campus security is a manual event log demo, not a live ID card, door access or CCTV integration.
- Financial aid is an application tracking demo, not an actual scholarship eligibility engine.
- Dining is a transaction record demo; purchases do not automatically deduct a real campus card balance.
- Use sample data only. Never enter real student personal information into this demo.
- Before deployment, add role-based permissions per record, audit logging, backups, HTTPS, secure environment configuration, validation, privacy review and security testing.
