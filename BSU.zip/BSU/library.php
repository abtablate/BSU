<?php
require_once __DIR__ . '/config/bootstrap.php';
require_login();
require_system_access('library');

$bookFields = ['isbn', 'title', 'author', 'copies_total', 'copies_available'];
$loanFields = ['student_id', 'book_id', 'borrowed_at', 'due_date', 'returned_at', 'status'];
$dailyFineRate = 10.00;
$calculateFine = static function (string $dueDate, ?string $endDate) use ($dailyFineRate): float {
    $due = new DateTimeImmutable($dueDate);
    $end = new DateTimeImmutable($endDate ?: date('Y-m-d'));
    return $end > $due ? $due->diff($end)->days * $dailyFineRate : 0.0;
};
$message = '';
$dialogToOpen = '';
$bookForm = ['id' => '', 'isbn' => '', 'title' => '', 'author' => '', 'copies_total' => '1', 'copies_available' => '1'];
$loanForm = ['id' => '', 'student_id' => '', 'book_id' => '', 'borrowed_at' => date('Y-m-d'), 'due_date' => '', 'returned_at' => '', 'status' => 'Borrowed'];
$studentProfiles = $pdo->query('SELECT student_id, full_name FROM students ORDER BY full_name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $recordId = (int)($_POST['record_id'] ?? 0);

    if (str_starts_with($action, 'archive_')) {
        if (!is_admin()) {
            http_response_code(403);
            exit('Not allowed');
        }
        $archiveTable = $action === 'archive_book' ? 'books' : ($action === 'archive_loan' ? 'library_loans' : null);
        if ($archiveTable !== null && $recordId > 0) {
            if ($archiveTable === 'books') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM library_loans WHERE book_id = ? AND archived_at IS NULL AND returned_at IS NULL AND status IN ('Borrowed', 'Overdue')");
                $stmt->execute([$recordId]);
                if ((int)$stmt->fetchColumn() > 0) {
                    flash('Return or archive active loans before archiving this book.', 'error');
                    redirect('library.php');
                }
                $stmt = $pdo->prepare('UPDATE books SET archived_at = CURRENT_TIMESTAMP WHERE id = ? AND archived_at IS NULL');
                $stmt->execute([$recordId]);
            } else {
                $pdo->beginTransaction();
                try {
                    $stmt = $pdo->prepare('SELECT book_id, status, returned_at FROM library_loans WHERE id = ? AND archived_at IS NULL FOR UPDATE');
                    $stmt->execute([$recordId]);
                    $loan = $stmt->fetch();
                    if ($loan && $loan['returned_at'] === null && in_array($loan['status'], ['Borrowed', 'Overdue'], true)) {
                        $stmt = $pdo->prepare('UPDATE books SET copies_available = LEAST(copies_total, copies_available + 1) WHERE id = ?');
                        $stmt->execute([$loan['book_id']]);
                    }
                    $stmt = $pdo->prepare('UPDATE library_loans SET archived_at = CURRENT_TIMESTAMP WHERE id = ? AND archived_at IS NULL');
                    $stmt->execute([$recordId]);
                    $pdo->commit();
                } catch (Throwable $exception) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $exception;
                }
            }
            flash('Record archived.');
        }
        redirect('library.php');
    }

    if ($action === 'save_book') {
        $dialogToOpen = 'bookDialog';
        foreach ($bookFields as $field) {
            $bookForm[$field] = trim($_POST[$field] ?? '');
        }
        $bookForm['id'] = $recordId ?: '';
        if ($bookForm['title'] === '' || $bookForm['copies_total'] === '' || $bookForm['copies_available'] === '') {
            $message = 'Complete the required book fields.';
        } elseif (!ctype_digit($bookForm['copies_total']) || !ctype_digit($bookForm['copies_available']) || (int)$bookForm['copies_available'] > (int)$bookForm['copies_total']) {
            $message = 'Enter valid copy counts. Available copies cannot exceed total copies.';
        } else {
            if ($recordId > 0) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM library_loans WHERE book_id = ? AND archived_at IS NULL AND returned_at IS NULL AND status IN ('Borrowed', 'Overdue')");
                $stmt->execute([$recordId]);
                $activeLoans = (int)$stmt->fetchColumn();
                if ((int)$bookForm['copies_total'] < $activeLoans || (int)$bookForm['copies_available'] + $activeLoans > (int)$bookForm['copies_total']) {
                    $message = 'Copy counts must allow for all active loans.';
                }
            }
        }
        if ($message === '' && $bookForm['title'] !== '' && $bookForm['copies_total'] !== '' && $bookForm['copies_available'] !== '' && ctype_digit($bookForm['copies_total']) && ctype_digit($bookForm['copies_available']) && (int)$bookForm['copies_available'] <= (int)$bookForm['copies_total']) {
            try {
                if ($recordId > 0) {
                    if (!is_admin()) {
                        http_response_code(403);
                        exit('Not allowed');
                    }
                    $stmt = $pdo->prepare('UPDATE books SET isbn = ?, title = ?, author = ?, copies_total = ?, copies_available = ? WHERE id = ? AND archived_at IS NULL');
                    $stmt->execute([$bookForm['isbn'] ?: null, $bookForm['title'], $bookForm['author'] ?: null, (int)$bookForm['copies_total'], (int)$bookForm['copies_available'], $recordId]);
                    flash('Book updated successfully.');
                } else {
                    $stmt = $pdo->prepare('INSERT INTO books (isbn, title, author, copies_total, copies_available) VALUES (?, ?, ?, ?, ?)');
                    $stmt->execute([$bookForm['isbn'] ?: null, $bookForm['title'], $bookForm['author'] ?: null, (int)$bookForm['copies_total'], (int)$bookForm['copies_available']]);
                    flash('Book added successfully.');
                }
                redirect('library.php');
            } catch (PDOException $exception) {
                $message = 'Could not save this book. Check that the ISBN is not duplicated.';
            }
        }
    } elseif ($action === 'save_loan') {
        $dialogToOpen = 'loanDialog';
        foreach ($loanFields as $field) {
            $loanForm[$field] = trim($_POST[$field] ?? '');
        }
        $loanForm['id'] = $recordId ?: '';
        $studentCheck = $pdo->prepare('SELECT 1 FROM students WHERE student_id = ?');
        $studentCheck->execute([$loanForm['student_id']]);
        $validStudent = (bool)$studentCheck->fetchColumn();
        if ($loanForm['student_id'] === '' || $loanForm['book_id'] === '' || $loanForm['borrowed_at'] === '' || $loanForm['due_date'] === '') {
            $message = 'Complete the required borrowing fields.';
        } elseif (!$validStudent) {
            $message = 'Choose a student that exists in the Student Information System.';
        } elseif (!in_array($loanForm['status'], ['Borrowed', 'Returned', 'Overdue'], true)) {
            $message = 'Choose a valid loan status.';
        } elseif ($loanForm['status'] === 'Returned' && $loanForm['returned_at'] === '') {
            $message = 'Enter the actual return date for a returned book.';
        } elseif ($loanForm['due_date'] < $loanForm['borrowed_at']) {
            $message = 'The return due date cannot be earlier than the borrow date.';
        } else {
            try {
                if ($recordId > 0) {
                    if (!is_admin()) {
                        http_response_code(403);
                        exit('Not allowed');
                    }
                    $pdo->beginTransaction();
                    $stmt = $pdo->prepare('SELECT book_id, status, returned_at FROM library_loans WHERE id = ? AND archived_at IS NULL FOR UPDATE');
                    $stmt->execute([$recordId]);
                    $oldLoan = $stmt->fetch();
                    if (!$oldLoan) throw new RuntimeException('Borrowing record not found.');
                    $newStatus = $loanForm['returned_at'] !== '' ? 'Returned' : $loanForm['status'];
                    $wasOpen = $oldLoan && $oldLoan['returned_at'] === null && in_array($oldLoan['status'], ['Borrowed', 'Overdue'], true);
                    $willBeOpen = $loanForm['returned_at'] === '' && in_array($newStatus, ['Borrowed', 'Overdue'], true);
                    $oldBookId = (int)($oldLoan['book_id'] ?? 0);
                    $newBookId = (int)$loanForm['book_id'];
                    if ($wasOpen && (!$willBeOpen || $oldBookId !== $newBookId)) {
                        $stmt = $pdo->prepare('UPDATE books SET copies_available = LEAST(copies_total, copies_available + 1) WHERE id = ?');
                        $stmt->execute([$oldBookId]);
                    }
                    if ($willBeOpen && (!$wasOpen || $oldBookId !== $newBookId)) {
                        $stmt = $pdo->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ? AND archived_at IS NULL AND copies_available > 0');
                        $stmt->execute([$newBookId]);
                        if ($stmt->rowCount() !== 1) throw new RuntimeException('No copies of the selected book are available.');
                    }
                    $fine = $calculateFine($loanForm['due_date'], $loanForm['returned_at'] ?: null);
                    $stmt = $pdo->prepare('UPDATE library_loans SET student_id = ?, book_id = ?, borrowed_at = ?, due_date = ?, returned_at = ?, fine = ?, status = ? WHERE id = ? AND archived_at IS NULL');
                    $stmt->execute([$loanForm['student_id'], $newBookId, $loanForm['borrowed_at'], $loanForm['due_date'], $loanForm['returned_at'] ?: null, $fine, $newStatus, $recordId]);
                    $pdo->commit();
                    flash('Borrowing record updated successfully.');
                } else {
                    $pdo->beginTransaction();
                    $newStatus = $loanForm['returned_at'] !== '' ? 'Returned' : $loanForm['status'];
                    $isOpen = $loanForm['returned_at'] === '' && in_array($newStatus, ['Borrowed', 'Overdue'], true);
                    if ($isOpen) {
                        $stmt = $pdo->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ? AND archived_at IS NULL AND copies_available > 0');
                        $stmt->execute([(int)$loanForm['book_id']]);
                        if ($stmt->rowCount() !== 1) throw new RuntimeException('No copies of the selected book are available.');
                    }
                    $fine = $calculateFine($loanForm['due_date'], $loanForm['returned_at'] ?: null);
                    $stmt = $pdo->prepare('INSERT INTO library_loans (student_id, book_id, borrowed_at, due_date, returned_at, fine, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
                    $stmt->execute([$loanForm['student_id'], (int)$loanForm['book_id'], $loanForm['borrowed_at'], $loanForm['due_date'], $loanForm['returned_at'] ?: null, $fine, $newStatus]);
                    $pdo->commit();
                    flash('Borrowing record added successfully.');
                }
                redirect('library.php');
            } catch (Throwable $exception) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $message = $exception instanceof RuntimeException ? $exception->getMessage() : 'Could not save this borrowing record. Make sure the selected book exists.';
            }
        }
    }
}

if (isset($_GET['edit_book']) && is_admin()) {
    $stmt = $pdo->prepare('SELECT id, isbn, title, author, copies_total, copies_available FROM books WHERE id = ? AND archived_at IS NULL');
    $stmt->execute([(int)$_GET['edit_book']]);
    $record = $stmt->fetch();
    if ($record) {
        $bookForm = $record;
        $dialogToOpen = 'bookDialog';
    }
}
if (isset($_GET['edit_loan']) && is_admin()) {
    $stmt = $pdo->prepare('SELECT id, student_id, book_id, borrowed_at, due_date, returned_at, status FROM library_loans WHERE id = ? AND archived_at IS NULL');
    $stmt->execute([(int)$_GET['edit_loan']]);
    $record = $stmt->fetch();
    if ($record) {
        $loanForm = $record;
        $dialogToOpen = 'loanDialog';
    }
}

$books = $pdo->query('SELECT id, isbn, title, author, copies_total, copies_available FROM books WHERE archived_at IS NULL ORDER BY title')->fetchAll();
$loans = $pdo->query('SELECT l.id, l.student_id, l.book_id, l.borrowed_at, l.due_date, l.returned_at, l.fine, l.status, b.title AS book_title FROM library_loans l INNER JOIN books b ON b.id = l.book_id WHERE l.archived_at IS NULL ORDER BY l.borrowed_at DESC, l.id DESC')->fetchAll();
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Library Management System | BSU Connect</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="library-page">
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="app-shell">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    <main class="main-content">
        <div class="page-top">
            <div>
                <p class="eyebrow red">CAMPUS SERVICE</p>
                <h1>Library Management</h1>
            </div>
            <span class="record-count"><?=number_format(count($books))?> books &middot; <?=number_format(count($loans))?> loans</span>
        </div>
        <?php if ($flash): ?><div class="alert success" role="status"><?=e($flash['message'])?></div><?php endif; ?>
        <?php if ($message): ?><div class="alert error" role="alert"><?=e($message)?></div><?php endif; ?>

        <section class="library-section" aria-labelledby="books-heading">
            <div class="library-section-heading">
                <div><h2 id="books-heading">Book collection</h2></div>
                <button class="btn primary library-add-button" type="button" data-open-dialog="bookDialog"><span aria-hidden="true">+</span> Add book</button>
            </div>
            <div class="table-panel">
                <div class="table-head"><div><h2>Books</h2><p class="muted">Available titles in the catalog</p></div><input class="search-input" data-table-search="booksTable" placeholder="Search books..." aria-label="Search books"></div>
                <div class="table-scroll"><table id="booksTable"><thead><tr><th>Title</th><th>ISBN</th><th>Author</th><th>Copies</th><th>Available</th><?php if (is_admin()): ?><th>Action</th><?php endif; ?></tr></thead><tbody>
                <?php foreach ($books as $book): ?><tr><td><?=e($book['title'])?></td><td><?=e($book['isbn'] ?? '')?></td><td><?=e($book['author'] ?? '')?></td><td><?=number_format((int)$book['copies_total'])?></td><td><?=number_format((int)$book['copies_available'])?></td><?php if (is_admin()): ?><td class="library-actions"><a class="edit-link" href="library.php?edit_book=<?=$book['id']?>">Edit</a><form method="post" onsubmit="return confirm('Archive this book? It will be hidden from the active catalog, but its record will be kept.')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="archive_book"><input type="hidden" name="record_id" value="<?=$book['id']?>"><button class="archive-link" type="submit">Archive</button></form></td><?php endif; ?></tr><?php endforeach; ?>
                <?php if (!$books): ?><tr><td colspan="<?=is_admin() ? 6 : 5?>" class="empty-state">No books in the active catalog yet.</td></tr><?php endif; ?></tbody></table></div>
            </div>
        </section>

        <section class="library-section" aria-labelledby="loans-heading">
            <div class="library-section-heading">
                <div><h2 id="loans-heading">Borrowing records</h2></div>
                <button class="btn primary library-add-button" type="button" data-open-dialog="loanDialog" <?=$books ? '' : 'disabled'?>> <span aria-hidden="true">+</span> Record a loan</button>
            </div>
            <div class="table-panel">
                <div class="table-head"><div><h2>Loans</h2><p class="muted">Latest borrowing activity</p></div><input class="search-input" data-table-search="loansTable" placeholder="Search loans..." aria-label="Search borrowing records"></div>
                <div class="table-scroll"><table id="loansTable"><thead><tr><th>Student ID</th><th>Book</th><th>Borrow date</th><th>Return due</th><th>Returned</th><th>Status</th><th>Penalty</th><?php if (is_admin()): ?><th>Action</th><?php endif; ?></tr></thead><tbody>
                <?php foreach ($loans as $loan): ?><?php $displayStatus = $loan['returned_at'] !== null ? 'Returned' : ($loan['due_date'] < date('Y-m-d') ? 'Overdue' : $loan['status']); $fine = $calculateFine($loan['due_date'], $loan['returned_at']); ?><tr><td><?=e($loan['student_id'])?></td><td><?=e($loan['book_title'])?></td><td><?=e($loan['borrowed_at'])?></td><td><?=e($loan['due_date'])?></td><td><?=e($loan['returned_at'] ?? '')?></td><td><span class="loan-status <?=e(strtolower($displayStatus))?>"><?=e($displayStatus)?></span></td><td>₱<?=number_format($fine, 2)?></td><?php if (is_admin()): ?><td class="library-actions"><a class="edit-link" href="library.php?edit_loan=<?=$loan['id']?>">Edit</a><form method="post" onsubmit="return confirm('Archive this borrowing record? The record will be kept but removed from the active list.')"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="archive_loan"><input type="hidden" name="record_id" value="<?=$loan['id']?>"><button class="archive-link" type="submit">Archive</button></form></td><?php endif; ?></tr><?php endforeach; ?>
                <?php if (!$loans): ?><tr><td colspan="<?=is_admin() ? 8 : 7?>" class="empty-state">No borrowing records yet. Record a loan when a book is checked out.</td></tr><?php endif; ?></tbody></table></div>
            </div>
        </section>
        <footer>BSU Connect &middot; Demonstration data only &middot; Not an official BSU platform</footer>
    </main>
</div>

<dialog class="record-dialog" id="bookDialog" aria-labelledby="bookDialogTitle">
    <div class="record-dialog-header"><div><h2 id="bookDialogTitle"><?=$bookForm['id'] ? 'Edit book' : 'Add book'?></h2><p>Enter the book catalog details.</p></div><button class="dialog-close" type="button" data-close-dialog="bookDialog" aria-label="Close dialog">&times;</button></div>
    <form method="post" class="record-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save_book"><input type="hidden" name="record_id" value="<?=e($bookForm['id'])?>">
        <div class="record-form-grid">
            <div class="record-field"><label for="book_title">Book title <span class="required">*</span></label><input id="book_title" name="title" value="<?=e($bookForm['title'])?>" required></div>
            <div class="record-field"><label for="book_isbn">ISBN</label><input id="book_isbn" name="isbn" value="<?=e($bookForm['isbn'] ?? '')?>"></div>
            <div class="record-field"><label for="book_author">Author</label><input id="book_author" name="author" value="<?=e($bookForm['author'] ?? '')?>"></div>
            <div class="record-field"><label for="copies_total">Total copies <span class="required">*</span></label><input id="copies_total" type="number" min="0" step="1" name="copies_total" value="<?=e($bookForm['copies_total'])?>" required></div>
            <div class="record-field"><label for="copies_available">Available copies <span class="required">*</span></label><input id="copies_available" type="number" min="0" step="1" name="copies_available" value="<?=e($bookForm['copies_available'])?>" required></div>
        </div>
        <div class="record-dialog-actions"><button class="dialog-cancel" type="button" data-close-dialog="bookDialog">Cancel</button><button class="btn primary" type="submit">Save book</button></div>
    </form>
</dialog>

<dialog class="record-dialog" id="loanDialog" aria-labelledby="loanDialogTitle">
    <div class="record-dialog-header"><div><h2 id="loanDialogTitle"><?=$loanForm['id'] ? 'Edit borrowing record' : 'Record a loan'?></h2><p>Enter the borrower and book return dates.</p></div><button class="dialog-close" type="button" data-close-dialog="loanDialog" aria-label="Close dialog">&times;</button></div>
    <form method="post" class="record-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="save_loan"><input type="hidden" name="record_id" value="<?=e($loanForm['id'])?>">
        <div class="record-form-grid">
            <div class="record-field"><label for="loan_student_id">Student <span class="required">*</span></label><select id="loan_student_id" name="student_id" required><option value="">Select student</option><?php foreach ($studentProfiles as $student): ?><option value="<?=e($student['student_id'])?>" <?=$loanForm['student_id'] === $student['student_id'] ? 'selected' : ''?>><?=e($student['student_id'].' — '.$student['full_name'])?></option><?php endforeach; ?></select></div>
            <div class="record-field"><label for="loan_book_id">Book <span class="required">*</span></label><select id="loan_book_id" name="book_id" required><option value="">Select a book</option><?php foreach ($books as $book): ?><option value="<?=$book['id']?>" <?=$loanForm['book_id'] == $book['id'] ? 'selected' : ''?>><?=e($book['title'])?></option><?php endforeach; ?></select></div>
            <div class="record-field"><label for="borrowed_at">Borrow date <span class="required">*</span></label><input id="borrowed_at" type="date" name="borrowed_at" value="<?=e($loanForm['borrowed_at'])?>" required></div>
            <div class="record-field"><label for="due_date">Return due date <span class="required">*</span></label><input id="due_date" type="date" name="due_date" value="<?=e($loanForm['due_date'])?>" required></div>
            <div class="record-field"><label for="returned_at">Actual return date</label><input id="returned_at" type="date" name="returned_at" value="<?=e($loanForm['returned_at'] ?? '')?>"></div>
            <div class="record-field"><label for="loan_status">Loan status <span class="required">*</span></label><select id="loan_status" name="status" required><option value="Borrowed" <?=$loanForm['status'] === 'Borrowed' ? 'selected' : ''?>>Borrowed</option><option value="Returned" <?=$loanForm['status'] === 'Returned' ? 'selected' : ''?>>Returned</option><option value="Overdue" <?=$loanForm['status'] === 'Overdue' ? 'selected' : ''?>>Overdue</option></select></div>
        </div>
        <div class="record-dialog-actions"><button class="dialog-cancel" type="button" data-close-dialog="loanDialog">Cancel</button><button class="btn primary" type="submit">Save borrowing record</button></div>
    </form>
</dialog>
<script>
document.querySelectorAll('[data-open-dialog]').forEach(button => button.addEventListener('click', () => document.getElementById(button.dataset.openDialog).showModal()));
document.querySelectorAll('[data-close-dialog]').forEach(button => button.addEventListener('click', () => document.getElementById(button.dataset.closeDialog).close()));
document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); }));
document.querySelectorAll('[data-table-search]').forEach(input => input.addEventListener('input', () => {
    const query = input.value.toLowerCase();
    document.querySelectorAll(`#${input.dataset.tableSearch} tbody tr`).forEach(row => row.style.display = row.innerText.toLowerCase().includes(query) ? '' : 'none');
}));
<?php if ($dialogToOpen !== ''): ?>document.getElementById(<?=json_encode($dialogToOpen)?>).showModal();<?php endif; ?>
<?php if ($message !== ''): ?>document.querySelector('.record-dialog[open] .record-form').insertAdjacentHTML('beforebegin', '<div class="alert error" role="alert"><?=e($message)?></div>');<?php endif; ?>
</script>
</body>
</html>
